#!/bin/bash
if [[ $EUID -ne 0 ]]; then
	echo "This script must be run as root"
	exit 1
fi

amount=$(find /etc -type f | wc -l)
echo "The amount of files is: $amount"
